﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace networkHelper
{
    public partial class Form1 : Form
    {
        Menu menu = new Menu(false, "menu name");
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.Black;
            this.Opacity = 0.50;
            this.FormBorderStyle = FormBorderStyle.None;
          /*  menu.initialize_setting("int1", 1, false,"int1");
            menu.initialize_setting("bool2", false, false, "int2");
            menu.addMenuParrent("Menu1");
            menu.initialize_setting("int2", 1, false, "name");
            menu.initialize_setting("bool22", false, false, "name");
            menu.initialize_setting("int2121", 1, false, "name");
            menu.initialize_setting("bool23123", false, false, "name");
            menu.addMenuParrent("Menu2");
            menu.initialize_setting("bool2tyu2", false, false, "name");
            menu.initialize_setting("int212ytuyt", 1, false, "name");
            menu.initialize_setting("bool2uytyu3123", false, false, "name");*/
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            menu.show(this);

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            menu.draw(e);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }

    public class Menu
    {
            //default settings do not change here
        public string settings_ini_filename = "Settings.ini";
        public Point location = new Point(100, 100);
        public int menu_width = 540;
        public string name = "Settings Menu";
        public bool debug = false;

        private void Init(bool _setting_debug, string _name, Point _location)
        {
            name = _name;
            debug = _setting_debug;
            Initialize(settings_ini_filename);
            addMenuParrent(_name);
            initialize_setting("debug", _setting_debug, false, "debug");
            initialize_setting("debug3", _setting_debug, false, "debug3");
            initialize_setting("debug4", 0, false, "debug44");
            initialize_setting("name", _name, false, "name");
            MessageBox.Show(get("menu_location", new Point(800, 800).ToString()));
            initialize_setting("menu_location", location.ToString(), false, "menu_location");
          
            string[] coords = get("menu_location", location.ToString()).Replace("{", "")
                .Replace("}", "").Replace("X=", "").Replace("Y=", "").Split(',');
            location = new Point(int.Parse(coords[0]), int.Parse(coords[1]));

            set("debug", _setting_debug);
            if (get("debug", false))
            {
                MessageBox.Show("Debug is enabled", _name);
            }

        }

        public void show(Form1 _this)
        {
            _this.TopMost = true;
            //clicktrough
            uint initialStyle = GetWindowLong(_this.Handle, -20);
            SetWindowLong(_this.Handle, -20, initialStyle | 0x80000 | 0x20);


        }
        public void hide()
        {

        }



        public void draw(PaintEventArgs e)
        {
            int menu_parent_count = 0;
            int itemcount = 0;
            int spacing = 20;
            float fontsie = 15;


            string[] coords = get("menu_location", location.ToString()).Replace("{", "")
               .Replace("}", "").Replace("X=", "").Replace("Y=", "").Split(',');
            MessageBox.Show(coords[0]);
            location = new Point(int.Parse(coords[0]), int.Parse(coords[1]));

            Color col = Color.LimeGreen;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixel;
            Brush brush = new SolidBrush(Color.FromArgb(255, 77, 77, 77));
            e.Graphics.FillRectangle(brush, location.X, location.Y, menu_width, 500);

            foreach (Menu_item it in menu_layout)
            {
                if (!it.hidden)
                {
                    String drawString = it.name + (get("debug",false) ?  (":" + it.key) : "");
                    Font drawFont = new Font("Arial", fontsie, FontStyle.Bold);

                    SolidBrush drawBrush = new SolidBrush(col);
                    float padding = 5.0F;
                    float parentpadding = padding;
                    if (it.parrent_id != 0) { parentpadding = padding + 20.0F; }
                    float y = 5.0F + (spacing * itemcount);
                    StringFormat drawFormat = new StringFormat();
                    if (menu_parent_count<=0) {
                        e.Graphics.DrawString(it.name, drawFont, drawBrush, parentpadding + location.X, y + location.Y, drawFormat);
                        itemcount++;
                    } else {

                        e.Graphics.DrawString(drawString, drawFont, drawBrush, parentpadding + location.X, y + location.Y, drawFormat);
                       
                        if (it.key != "")
                        {
                            drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                            e.Graphics.DrawString(getstring(it.key), drawFont, drawBrush, menu_width - padding + location.X, y + location.Y, drawFormat);
                        }
                        else
                        {
                            drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                            e.Graphics.DrawString("open", drawFont, drawBrush, menu_width - padding + location.X, y + location.Y, drawFormat);
                        }
                        itemcount++;
                    }

                    if (it.parrent_id == 0) {
                        menu_parent_count++;
                    }

                }
            }
        }

        public Menu()
        {
            Init(debug, name, location);
        }
        public Menu(Point _location)
        {
            Init(debug, name, _location);
        }
        public Menu(string _name)
        {
            Init(debug, _name, location);
        }
        public Menu(bool _setting_debug)
        {
            Init(_setting_debug, name, location);
        }

        public Menu(string _name, Point _location)
        {
            Init(debug, _name, _location);
        }

        public Menu(bool _setting_debug, string _name)
        {
            Init(_setting_debug, _name, location);
        }

        public Menu(bool _setting_debug, Point _location)
        {
            Init(_setting_debug, name, _location);
        }

        public Menu(bool _setting_debug, string _name, Point _location)
        {
            Init(_setting_debug, _name, _location);
        }

        public class Menu_item
        {
            public Menu_item(int _parrentid, int _added_index, string _key, string _name, Type _type)
            {
                added_index = _added_index;
                key = _key;
                name = _name;
                parrent_id = _parrentid;
                type = _type;
            }
            public Menu_item(int _parrentid, int _added_index, string _key, string _name, Type _type, bool _hidden)
            {
                added_index = _added_index;
                key = _key;
                name = _name;
                parrent_id = _parrentid;
                type = _type;
                hidden = _hidden;
            }
            public Menu_item(int _parrentid, string _key, string _name)
            {
                key = _key;
                name = _name;
                parrent_id = _parrentid;
            }
            public Type type = typeof(string);
            public string key = "keyname";
            public int added_index = -1;
            public int parrent_id = -1;
            public int index = -1;
            public string name = "Menu Item";
            public bool hidden = false;
            public bool enabled = true;
        }


        //public Dictionary<string, Menu_item> menu_layout = new Dictionary<string, Menu_item>();
        public List<Menu_item> menu_layout = new List<Menu_item>();
        private int layout_counter = 0;
        private int menu_parrents_counter = 0;

        public Dictionary<string, string> _string = new Dictionary<string, string>();
        public Dictionary<string, bool> _bool = new Dictionary<string, bool>();
        public Dictionary<string, int> _int = new Dictionary<string, int>();
        public Dictionary<string, long> _long = new Dictionary<string, long>();
        public Dictionary<string, double> _double = new Dictionary<string, double>();
        public Dictionary<string, float> _float = new Dictionary<string, float>();

        public int addMenuParrent(string name)
        {
            menu_layout.Add(new Menu_item(menu_parrents_counter, "", name));
            menu_parrents_counter++;
            return 0;
        }

        public void Initialize(string IniPath = null)
        {
            Path = new System.IO.FileInfo(IniPath ?? EXE + ".ini").FullName;
        }
        public void initialize_setting(string key, string value, bool hidden,string _name)
        {
            _string[key] = _get_s(key, value);
            menu_layout.Add(new Menu_item(menu_parrents_counter, layout_counter++, key, _name, typeof(string)));

        }
        public void initialize_setting(string key, bool value, bool hidden, string _name)
        {
            _bool[key] = _get_b(key, value);
            menu_layout.Add(new Menu_item(menu_parrents_counter, layout_counter++, key, _name, typeof(bool)));
        }
        public void initialize_setting(string key, int value, bool hidden, string _name)
        {
            _int[key] = _get_i(key, value);
            menu_layout.Add(new Menu_item(menu_parrents_counter, layout_counter++, key, _name, typeof(int)));
        }
        public void initialize_setting(string key, long value, bool hidden, string _name)
        {
            _long[key] = _get_l(key, value);
            menu_layout.Add(new Menu_item(menu_parrents_counter, layout_counter++, key, _name, typeof(long)));
        }
        public void initialize_setting(string key, double value, bool hidden, string _name)
        {
            _double[key] = _get_d(key, value);
            menu_layout.Add(new Menu_item(menu_parrents_counter, layout_counter++, key, _name, typeof(double)));
        }

        public void set(string key, bool value)
        {
            try { Write(key, value.ToString()); } catch { }
            _bool[key] = value;
        }
        public void set(string key, int value)
        {
            try { Write(key, value.ToString()); } catch { }
            _int[key] = value;
        }
        public void set(string key, string value)
        {
            try { Write(key, value.ToString()); } catch { }
            _string[key] = value;
        }
        public void set(string key, long value)
        {
            try { Write(key, value.ToString()); } catch { }
            _long[key] = value;
        }
        public void set(string key, double value)
        {
            try { Write(key, value.ToString()); } catch { }
            _double[key] = value;
        }
        public void set(string key, float value)
        {
            try { Write(key, value.ToString()); } catch { }
            _float[key] = value;
        }


        public string getstring(string key)
        {
            if (_bool.ContainsKey(key))
                try
                {
                    return _bool[key].ToString();
                }
                catch { }
            if (_int.ContainsKey(key))
                try
                {
                    return _int[key].ToString();
                }
                catch { }
            if (_string.ContainsKey(key))
                try
                {
                    return _string[key].ToString();
                }
                catch { }
            if (_long.ContainsKey(key))
                try
                {
                    return _long[key].ToString();
                }
                catch { }
            if (_double.ContainsKey(key))
                try
                {
                    return _double[key].ToString();
                }
                catch { }
            if (_float.ContainsKey(key))
                try
                {
                    return _float[key].ToString();
                }
                catch { }
            return "cant find setting";
        }

        public bool get(string key, bool b = false)
        {
            try
            {
                return _bool[key];
            }
            catch { }
            return b;
        }
        public float get(string key, float f = 0.0F)
        {
            try
            {
                return _float[key];
            }
            catch { }
            return f;
        }
        public int get(string key, int i = 0)
        {
            try
            {
                return _int[key];
            }
            catch { }
            return i;
        }
        public string get(string key, string s = "")
        {
            try
            {
                return _string[key];
            }
            catch { }
            return s;
        }
        public long get(string key, long l = 0)
        {
            try
            {
                return _long[key];
            }
            catch { }
            return l;
        }
        public double get(string key, double d = 0.0)
        {
            try
            {
                return _double[key];
            }
            catch { }
            return d;
        }

        public string _get_s(string _key, string default_value = "test")
        {
            try
            {
                string tr = Read(_key);
                if(tr == "")
                {
                    try { Write(_key, default_value); } catch { }
                }
                return default_value;
            }
            catch
            {
                try { Write(_key, default_value); } catch { }
            }
            return default_value;
        }
        public bool _get_b(string _key, bool default_value = false)
        {
            try
            {
                return bool.Parse(Read(_key));
            }
            catch
            {
                try { Write(_key, default_value.ToString()); } catch { }
            }
            return default_value;
        }
        public int _get_i(string _key, int default_value = 0)
        {
            try
            {
                return int.Parse(Read(_key));
            }
            catch
            {
                try { Write(_key, default_value.ToString()); } catch { }
            }
            return default_value;
        }
        public long _get_l(string _key, long default_value = 0)
        {
            try
            {
                return long.Parse(Read(_key));
            }
            catch
            {
                try { Write(_key, default_value.ToString()); } catch { }
            }
            return default_value;
        }
        public double _get_d(string _key, double default_value = 0.0)
        {
            try
            {
                return long.Parse(Read(_key));
            }
            catch
            {
                try { Write(_key, default_value.ToString()); } catch { }
            }
            return default_value;
        }
        public float _get_f(string _key, float default_value = 0.0F)
        {
            try
            {
                return float.Parse(Read(_key));
            }
            catch
            {
                try { Write(_key, default_value.ToString()); } catch { }
            }
            return default_value;
        }

        [System.Runtime.InteropServices.DllImport("kernel32", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern long WritePrivateProfileString(string Section, string Key, string Value, string FilePath);

        [System.Runtime.InteropServices.DllImport("kernel32", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern int GetPrivateProfileString(string Section, string Key, string Default, StringBuilder RetVal, int Size, string FilePath);

        public string Read(string Key, string Section = null)
        {
            var RetVal = new StringBuilder(255);
            GetPrivateProfileString(Section ?? EXE, Key, "", RetVal, 255, Path);
            return RetVal.ToString();
        }

        public void Write(string Key, string Value, string Section = null)
        {
            WritePrivateProfileString(Section ?? EXE, Key, Value, Path);
        }

        public void DeleteKey(string Key, string Section = null)
        {
            Write(Key, null, Section ?? EXE);
        }

        public void DeleteSection(string Section = null)
        {
            Write(null, null, Section ?? EXE);
        }

        public bool KeyExists(string Key, string Section = null)
        {
            return Read(Key, Section).Length > 0;
        }

    }

}
