﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nwh
{
    public partial class Form1 : Form
    {
       

        Menu menu = new Menu(false/*set debug for c# testing*/);

        public Form1()
        {
          
            InitializeComponent();
   
            menu.initialize_form(this);
         

            //create menu
            menu.settings.add_title("War is on - Menu - 1.2.3");
            //create menu folder
            menu.settings.add_foldable_menu("Basic settings");
            menu.settings.initialize_new_setting("Auto trigger enabled", "triggetbot", false);
            menu.settings.initialize_new_setting("Lag on autotrigger enabled", "triggetbot_lag", false);
            menu.settings.initialize_new_setting("Lag on manual enabled", "lag_on_trigger", false);
            menu.settings.initialize_new_setting("Lag on hotkey enabled", "lag_on_hotkey", false);
            menu.settings.initialize_new_setting("Lag long on hotkey enabled", "lag_long_on_hotkey", false);

            //create menu folder
            menu.settings.add_foldable_menu("Advanced bot settings");
            menu.settings.initialize_new_setting("Hotkey for lag", "lag_hot_key", (int)Keys.V);
            menu.settings.initialize_new_setting("Hotkey for long lag", "long_lag_hot_key", (int)Keys.B);
            menu.settings.initialize_new_setting("crosshair_center_X", "crosshair_center_X", 0);
            menu.settings.initialize_new_setting("crosshair_center_Y", "crosshair_center_Y", 0);
            menu.settings.initialize_new_setting("Draw detection crosshair", "crosshair", true);
            menu.settings.initialize_new_setting("name_detection_Y", "name_detection_Y", 0);
            menu.settings.initialize_new_setting("detextionY_offsetY", "detextionY_offsetY", 35);
            menu.settings.initialize_new_setting("Show graphical detection area", "ShowDetectionArea", false);
            menu.settings.initialize_new_setting("Show graphical detection area on screen", "ShowDetectionArea_onscreen", false);

            //create menu folder
            menu.settings.add_foldable_menu("Advanced timeout settings");
            menu.settings.initialize_new_setting("Triger hold timeout", "triggetbot_hold_timing", 700);
            menu.settings.initialize_new_setting("Lag on autotrigger timeout", "triggetbot_lag_timing", 500);
            menu.settings.initialize_new_setting("Lag on trigger timeout", "manual_lag_timing", 100);
            menu.settings.initialize_new_setting("Lag on hotkey timeout", "lag_on_hotkey_timeout", 1200);
            menu.settings.initialize_new_setting("Lag on hotkey timeout", "lag_long_on_hotkey_timeout", 2200);


            //add the bottom debug etc..
            menu.settings.add_footer();
          
        }

  
  
        bdbd bood = new bdbd();
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            menu.draw(e);
            bood.loop(e,menu);
        }

       public class bdbd
        {


           private  int screencenterx = System.Windows.Forms.Screen.AllScreens[0].Bounds.Width / 2;
            private int screencentery = System.Windows.Forms.Screen.AllScreens[0].Bounds.Height / 2;
            private int setcenternumber = -1;
            public void setcenter(int screennumber)
            {
                if (screennumber != setcenternumber && screennumber < System.Windows.Forms.Screen.AllScreens.Count() && screennumber>=0)
                {
                    setcenternumber = screennumber;
                    screencenterx = System.Windows.Forms.Screen.AllScreens[screennumber].Bounds.Width / 2;
                    screencentery = System.Windows.Forms.Screen.AllScreens[screennumber].Bounds.Height / 2;
                }
            }

            public Bitmap bs_debug = new Bitmap(50, 150);
            public Bitmap bs = new Bitmap(50, 50);
            public Bitmap screenimg = new Bitmap(120, 50);
            public Bitmap crosshair_holder = new Bitmap(50, 50);







            /*

           menu.settings.initialize_new_setting("Auto trigger enabled", "triggetbot", false);
            menu.settings.initialize_new_setting("Lag on autotrigger enabled", "triggetbot_lag", false);
            menu.settings.initialize_new_setting("Lag on manual enabled", "lag_on_trigger", false);
            menu.settings.initialize_new_setting("Lag on hotkey enabled", "lag_on_hotkey", false);
            menu.settings.initialize_new_setting("Lag long on hotkey enabled", "lag_long_on_hotkey", false);

            //create menu folder
            menu.settings.add_foldable_menu("Advanced bot settings");
            menu.settings.initialize_new_setting("Hotkey for lag", "lag_hot_key", (int)Keys.V);
            menu.settings.initialize_new_setting("Hotkey for long lag", "long_lag_hot_key", (int)Keys.B);
            menu.settings.initialize_new_setting("crosshair_center_X", "crosshair_center_X", 0);
            menu.settings.initialize_new_setting("crosshair_center_Y", "crosshair_center_Y", 0);
            menu.settings.initialize_new_setting("Draw detection crosshair", "crosshair", true);
            menu.settings.initialize_new_setting("name_detection_Y", "name_detection_Y", 0);
            menu.settings.initialize_new_setting("Show graphical detection area", "ShowDetectionArea", false);
            menu.settings.initialize_new_setting("Show graphical detection area on screen", "ShowDetectionArea_onscreen", false);

            //create menu folder
            menu.settings.add_foldable_menu("Advanced timeout settings");
            menu.settings.initialize_new_setting("Triger hold timeout", "triggetbot_hold_timing", 700);
            menu.settings.initialize_new_setting("Lag on autotrigger timeout", "triggetbot_lag_timing", 500);
            menu.settings.initialize_new_setting("Lag on trigger timeout", "manual_lag_timing", 100);
            menu.settings.initialize_new_setting("Lag on hotkey timeout", "lag_on_hotkey_timeout", 1200);
            menu.settings.initialize_new_setting("Lag on hotkey timeout", "lag_long_on_hotkey_timeout", 2200);


             */
            Random r = new Random();

            public void clickc(Menu menu)
            {
                if (!(Control.MouseButtons == MouseButtons.Left))
                {
                    Thread.Sleep(r.Next(1, 5));
                    mouse_event(0x0002, (uint)GetCursorPosition().X * 65535, (uint)GetCursorPosition().Y * 65535, 0, 0);
                    Thread.Sleep(menu.settings.get("triggetbot_hold_timing", 700));
                    mouse_event(0x0004, (uint)GetCursorPosition().X * 65535, (uint)GetCursorPosition().Y * 65535, 0, 0);
                    Thread.Sleep(r.Next(20, 30));
                    if (Control.MouseButtons == MouseButtons.Left)
                    {
                        mouse_event(0x0002, (uint)GetCursorPosition().X * 65535, (uint)GetCursorPosition().Y * 65535, 0, 0);
                    }
                    Thread.Sleep(r.Next(20, 30));
                    if (!(Control.MouseButtons == MouseButtons.Left))
                    {
                        mouse_event(0x0004, (uint)GetCursorPosition().X * 65535, (uint)GetCursorPosition().Y * 65535, 0, 0);
                    }
                    Thread.Sleep(100 + r.Next(5, 50));
                }
            }


            public void loop(PaintEventArgs e, Menu menu)
            {
                int offcetyMid = menu.settings.get("detextionY_offsetY", 25);
                if (menu.settings.get("ShowDetectionArea", true))
                {
                    try
                    {
                        Graphics graphics = Graphics.FromImage(bs_debug as Image);
                        graphics.CopyFromScreen((screencenterx - bs.Width / 2) + menu.settings.get("crosshair_center_X", 0), (screencentery) + menu.settings.get("crosshair_center_Y", 0) - (bs_debug.Height - bs.Height) + offcetyMid, 0, 0, bs_debug.Size);
                    }
                    catch { }
                }

                try
                {
                    Graphics graphics2 = Graphics.FromImage(bs as Image);
                    graphics2.CopyFromScreen((screencenterx - bs.Width / 2) + menu.settings.get("crosshair_center_X", 0), (screencentery) + menu.settings.get("crosshair_center_Y", 0) + offcetyMid, 0, 0, bs.Size);
                }
                catch { }

                int menulocationx = menu.settings.get("menulocationx", 60);
                int menulocationy = menu.settings.get("menulocationy", 60);
                int countDetectedPixels = 0;
                int countDetectedPixels2 = 0;
                int offset = 10;
                int detheigh = menu.settings.get("name_detection_Y", 0);
                //avoids user tu input to high number
                if (detheigh >= 17)
                {
                    detheigh = 17;
                }
                if (detheigh <= -18)
                {
                    detheigh = -18;
                }
                bool detected(int xx)
                {

                    Color c1 = bs.GetPixel(offset + xx, (bs.Height / 2) + 1 + detheigh);
                    return (c1.R > 190 && c1.G < 50 && c1.B < 50);

                }
                bool detected2(int xx)
                {

                    Color c1 = bs.GetPixel(offset + xx, (bs.Height / 2) + 2 + detheigh);
                    return (c1.R > 190 && c1.G < 50 && c1.B < 50);


                }

                for (int ii = 0; ii < (bs.Width - offset) - offset; ii++)
                {

                    if (detected(ii))
                    {
                        if (menu.settings.get("ShowDetectionArea", true)) {
                            bs.SetPixel(offset + ii, (bs.Height / 2) + 1 + detheigh, Color.Green);
                            bs_debug.SetPixel(offset + ii, (bs_debug.Height - bs.Height) + (bs.Height / 2) + 1 + detheigh, Color.Green);
                        }
                        countDetectedPixels++;
                    }
                    if (detected2(ii))
                    {
                        //draw detected pixels
                        if (menu.settings.get("ShowDetectionArea", true))
                        {
                            bs.SetPixel(offset + ii, (bs.Height / 2) + 2 + detheigh, Color.Green);
                            bs_debug.SetPixel(offset + ii, (bs_debug.Height - bs.Height) + (bs.Height / 2) + 2 + detheigh, Color.Green);
                        }
                        countDetectedPixels2++;
                    }

                    if (countDetectedPixels + countDetectedPixels2 > 3 && countDetectedPixels + countDetectedPixels2 <= 25)
                    {
                        if (!menu.settings.get("ShowDetectionArea", true))
                        {
                            break;
                        }
                    }

                    if (menu.settings.get("ShowDetectionArea", true))
                    {
                        bs.SetPixel(offset + ii, (bs.Height / 2) + detheigh, Color.Blue);
                        bs_debug.SetPixel(offset + ii, (bs_debug.Height - bs.Height) + (bs.Height / 2) + detheigh, Color.Blue);
                    }
                    //draw white line above detection

                }

                //(screencenterx - bs.Width/2) + menu.settings.get("crosshair_center_X", 0), (screencentery) + menu.settings.get("crosshair_center_Y", 0) - (bs_debug.Height - bs.Height)

               /* bs_debug.SetPixel(+bs_debug.Width / 2, 1, Color.Red);
                bs_debug.SetPixel(+bs_debug.Width / 2, 2, Color.Red);
                bs_debug.SetPixel(+bs_debug.Width / 2, 3, Color.Red);
                bs_debug.SetPixel(+bs_debug.Width / 2, 4, Color.Red);
               */
                if (menu.settings.get("ShowDetectionArea", true))
                {
                    e.Graphics.DrawImage(bs_debug, menulocationx - 50, menulocationy + 10);
                    //enlage image to see detection
                    using (Graphics g = Graphics.FromImage(screenimg))
                    {
                        g.DrawImage(bs, -(bs.Width - 11), -(bs.Height + (bs.Height / 2)), bs.Width * 4, bs.Height * 4);
                    }

                    // e.Graphics.DrawImage(bs, menulocationx + menu.settings.get("width", 60) / 2, menulocationy + 20, bs.Width, bs.Height);
                    e.Graphics.DrawImage(screenimg, menulocationx - 120, menulocationy + bs_debug.Height, screenimg.Width, screenimg.Height);
                }

                if (menu.settings.get("crosshair", true))
                {

                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) - 7, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) - 6, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) - 5, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) - 4, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) - 3, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) - 2, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) - 1, (crosshair_holder.Height / 2), Color.Red);
                    // crosshair_holder.SetPixel((crosshair_holder.Width / 2) , (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) + 1, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) + 2, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) + 3, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) + 4, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) + 5, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) + 6, (crosshair_holder.Height / 2), Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2) + 7, (crosshair_holder.Height / 2), Color.Red);




                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) - 7, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) - 6, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) - 5, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) - 4, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) - 3, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) - 2, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) - 1, Color.Red);
                    //  crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) , Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) + 1, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) + 2, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) + 3, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) + 4, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) + 5, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) + 6, Color.Red);
                    crosshair_holder.SetPixel((crosshair_holder.Width / 2), (crosshair_holder.Height / 2) + 7, Color.Red);

                    e.Graphics.DrawImage(crosshair_holder, (screencenterx - crosshair_holder.Width / 2) + menu.settings.get("crosshair_center_X", 0), (screencentery - crosshair_holder.Height / 2) + menu.settings.get("crosshair_center_Y", 0), crosshair_holder.Width, crosshair_holder.Height);
                }


                if (countDetectedPixels + countDetectedPixels2 > 3 && countDetectedPixels + countDetectedPixels2 <= 25)
                {
                    //if detected enemy click to shoot
                    if (menu.settings.get("triggetbot", true)) {
                        clickc(menu);
                    }
                }
            }

            private static void lagg(string[] ipp)
            {
                using (var networkConfigMng = new ManagementClass("Win32_NetworkAdapterConfiguration"))
                {
                    using (var networkConfigs = networkConfigMng.GetInstances())
                    {
                        foreach (var managementObject in networkConfigs.Cast<ManagementObject>().Where(managementObject => (bool)managementObject["IPEnabled"]))
                        {

                            using (var newIP = managementObject.GetMethodParameters("EnableStatic"))
                            {
                                using (var newGateway = managementObject.GetMethodParameters("SetGateways"))
                                {
                                    newGateway["DefaultIPGateway"] = ipp;
                                    newGateway["GatewayCostMetric"] = new[] { 1 };
                                    managementObject.InvokeMethod("SetGateways", newGateway, null);
                                }

                            }
                        }
                    }
                }
            }

            private const int WM_NCLBUTTONDOWN = 0xA1;
            private const int HT_CAPTION = 0x2;
            private const int MOUSEEVENTF_MOVE = 0x0001;
            private const int MOUSEEVENTF_LEFTDOWN = 0x0002;
            private const int MOUSEEVENTF_LEFTUP = 0x0004;
            private const int MOUSEEVENTF_RIGHTDOWN = 0x0008;

            [DllImport("user32.dll")] private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
            [DllImport("user32.dll")] private static extern bool ReleaseCapture();
            [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
            private static extern void mouse_event(int dwFlags, uint dx, uint dy, int cButtons, int dwExtraInfo);

            [StructLayout(LayoutKind.Sequential)]
            private struct POINT
            {
                public int X;
                public int Y;

                public static implicit operator Point(POINT point)
                {
                    return new Point(point.X, point.Y);
                }
            }
            [DllImport("user32.dll")] private static extern bool GetCursorPos(out POINT lpPoint);
            private static Point GetCursorPosition()
            {
                POINT lpPoint;
                GetCursorPos(out lpPoint);
                return lpPoint;
            }

          
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          this.Opacity = menu.settings.get("opacity", 0.0);
          this.Invalidate();
          menu.form_clickable_loop_inside_timer(this);
          menu.form_menu_display_on_monitor_loop_inside_timer(this);
          bood.setcenter(menu.settings.get("menu_display_on_monitor", 0));
        }





    }
}
