﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nwh
{
    public class Menu
    {
        private bool running = true;
        private bool menu_active = true;
        private bool _d_ebug_ = false;//debug
        private int selcted_item_index = 3;
        private int maxitems = 0;
        private string selecteditemkey = "";
        private string selecteditemdes = "";
        private int selecteditm_add_index_index = -1;
        private int searchfordebugitem = 0;


                        //debug
        public Menu(bool d_ebug_ = false)
        {
            //debug
            _d_ebug_ = d_ebug_;
        }

        //initialize all settings

        public Menu_Settings settings = new Menu_Settings();
        public void initialize_form(Form _this)
        {
            //overrite setting to be true //debug
            if (_d_ebug_) settings.set("debug", true);

            //set default settings
            settings.initialize_new_setting("Debug is enabled", "debug", _d_ebug_);
            settings.initialize_new_setting("Menu width", "width", 240);
            settings.initialize_new_setting("Debug menu width", "debug_width", 240);
         

            //initialize form
            _this.BackColor = Color.Black;
            _this.Opacity = settings.get("opacity",0.70);
            _this.FormBorderStyle = FormBorderStyle.None;
            _this.TopMost = true;
            _this.TransparencyKey = _this.BackColor;



           // _this.Height = Screen.PrimaryScreen.Bounds.Height;
           // _this.Width = Screen.PrimaryScreen.Bounds.Width;
            _this.FormClosing += _this_FormClosing;
            _this.StartPosition = FormStartPosition.Manual;




                 int display = settings.get("menu_display_on_monitor", 0);
                try
                {
                    if (display <= Screen.AllScreens.Count())
                    {
                    _this.WindowState = FormWindowState.Normal;
                    _this.Location = Screen.AllScreens[display].WorkingArea.Location;
                       
                        _this.WindowState = FormWindowState.Maximized;
                    }
                    else
                    {
                    _this.WindowState = FormWindowState.Normal;
                    _this.Location = Screen.AllScreens[0].WorkingArea.Location;
                     _this.WindowState = FormWindowState.Maximized;
                    }
                }
                catch
                {
                    _this.WindowState = FormWindowState.Normal;
                    _this.Location = Screen.AllScreens[0].WorkingArea.Location;
                    _this.WindowState = FormWindowState.Maximized;
                }
            


        

            //click trough form you can remove this if you wanna make a click option somwhere
            uint initialStyle = GetWindowLong(_this.Handle, -20);
            SetWindowLong(_this.Handle, -20, initialStyle | 0x80000 | 0x20);

            //SetWindowLong(_this.Handle, -20, initialStyle | 0x80000 | 0x50);

            add_hotkeys(_this);
        }

        private bool form_clickable_loop_last = true;
        public void form_clickable_loop_inside_timer(Form _this)
        {
            uint initialStyle = GetWindowLong(_this.Handle, -20);
            if (form_clickable_loop_last && settings.get("clickable", false))
            {
                SetWindowLong(_this.Handle, -20, initialStyle | 0x80000 | 0x20);
                form_clickable_loop_last = false;
                //MessageBox.Show("Test");
            }
            else if (!form_clickable_loop_last && !settings.get("clickable", false))
            {
                SetWindowLong(_this.Handle, 0, initialStyle | 0x00000 | 0x10);
           
                form_clickable_loop_last = true;
                //MessageBox.Show("TestF");
            }
        }

        private int menu_display_on_monitor_last = -1;
        public void form_menu_display_on_monitor_loop_inside_timer(Form _this)
        {
            int display = settings.get("menu_display_on_monitor", 0);
            if (display != menu_display_on_monitor_last) {
                
               // try
               // {
                    if (display>=0 && display < Screen.AllScreens.Count())
                    {
                    _this.WindowState = FormWindowState.Normal;
                    _this.Location = Screen.AllScreens[display].WorkingArea.Location;
                    int screenwidth = Screen.AllScreens[display].Bounds.Width;
                    settings.set("menulocationx", (screenwidth - (settings.get("debug", true) ? 20 : 20)) - settings.get("width", 300));
                    _this.WindowState = FormWindowState.Maximized;
                      menu_display_on_monitor_last = display;
                    }
              //  }
               // catch (Exception e) {}
            }
        }

        private void _this_FormClosing(object sender, FormClosingEventArgs e)
        {
            running = false;

            //save settings maby?

        }

        public void draw(PaintEventArgs e)
        {
            if (!menu_active) return;

            int bg_alpga = settings.get("background_alpha", 255);
            if (bg_alpga <= 0)
            {
                settings.set("background_alpha", 0);
                bg_alpga = 0;
            }
            if (bg_alpga > 255)
            {
                settings.set("background_alpha", 255);
                bg_alpga = 255;
            }

            float fontsie = 10;
            float padding = 5.0F;
            int spacing = 25;
            int menulocationx = settings.get("menulocationx", 60);
            int menulocationy = settings.get("menulocationy", 60);
            int itemcount = 0;
            int menuwidth = settings.get("debug", false) ? (int)(settings.get("debug_width", 0)) : settings.get("width", 0);
            int shownextitem = 1;
            int maxitems_temp = 0;
            int menu_height_counter = 0;

            //  less smooth text for transparent backgrounds
            //  e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixel;

            Font drawFont = new Font("Arial", fontsie, FontStyle.Regular);

            //debug
            int extradebugcount = 0;//debug
            int extradebugcount2 = 0;//debug
            int extradebugcount3 = 0;//debug
            int deb2left = 300;//debug


            SolidBrush headerselectednotfolded = new SolidBrush(Color.FromArgb(bg_alpga, 255,255,50));
            SolidBrush headerselectedfolded = new SolidBrush(Color.AliceBlue);

            SolidBrush headernotselectednotfolded = new SolidBrush(Color.Orange);
            SolidBrush headernotselectedfolded = new SolidBrush(Color.FromArgb(bg_alpga, 255,255,255));

            SolidBrush selectdbrush = new SolidBrush(Color.White);
            SolidBrush normalcolor = new SolidBrush(Color.FromArgb(bg_alpga, 0, 255, 0));

            SolidBrush tempcol;

            StringFormat drawFormat = new StringFormat();
         
            Brush brushbbg = new SolidBrush(Color.FromArgb(bg_alpga, 50,50,50));
            Brush brushbbg2 = new SolidBrush(Color.FromArgb(bg_alpga,45,45,45));

            Brush brushwhite = new SolidBrush(Color.FromArgb(bg_alpga,0, 255, 0));
            Brush brushselected = new SolidBrush(Color.FromArgb(bg_alpga, 100, 255, 255));
            Brush brushtitle = new SolidBrush(Color.FromArgb(bg_alpga, 255,100,  255));

            foreach (Menu_Settings.menu_item itm in settings.setting_items_list)
            {

                       //debug
                if (settings.get("debug", true) /*|| itm.key == "debug"*/ || (itm.show_index >= -1 && (itm.key == "header_key_item_title" ||itm.key == "header_key_item" || itm.type != typeof(string))))
                {

                    if (shownextitem == 1 || itm.key == "header_key_item_title" || itm.key == "header_key_item" /*|| itm.key == "debug"*/)
                    {

                        float y = 5.0F + (spacing * itemcount);
                        string menuname = itm.discription + (settings.get("debug", false) ? "" : "");
                        if (itm.discription.Contains("{Open-Close-Key}"))
                        {
                            menuname = menuname.Replace("{Open-Close-Key}", ((Keys)settings.get("menu_open_hot_key", 0)).ToString());

                        }

                        if (itemcount == selcted_item_index)
                        {
                            e.Graphics.FillRectangle(brushbbg2, menulocationx, menulocationy + y, padding + menuwidth, spacing);
                        }
                        else
                        {
                           e.Graphics.FillRectangle(brushbbg, menulocationx, menulocationy + y, padding + menuwidth, spacing);

                        }
                        e.Graphics.FillRectangle(brushwhite, menulocationx, menulocationy + y, 2, spacing);
                        e.Graphics.FillRectangle(brushwhite, menulocationx + menuwidth + 2, menulocationy + y, 2, spacing);

                        if (itm.key == "header_key_item")
                        {

                            if (itemcount == selcted_item_index && itm.folded)
                            {
                                tempcol = headerselectedfolded;
                                e.Graphics.DrawString(menuname, drawFont, tempcol, padding + menulocationx, padding + y + menulocationy, drawFormat);
                            }
                            else if (itemcount == selcted_item_index && !itm.folded)
                            {
                                tempcol = headerselectednotfolded;
                                e.Graphics.DrawString(menuname, drawFont, tempcol, padding + menulocationx, padding + y + menulocationy, drawFormat);
                            }
                            else if (itm.folded)
                            {
                                tempcol = headernotselectedfolded;
                                e.Graphics.DrawString(menuname, drawFont, tempcol, padding + menulocationx, padding + y + menulocationy, drawFormat);
                            }
                            else
                            {
                                tempcol = headernotselectednotfolded;
                                e.Graphics.DrawString(menuname, drawFont, tempcol, padding + menulocationx, padding + y + menulocationy, drawFormat);
                            }

                        }
                        else
                        {
                            if (itemcount == selcted_item_index)
                            {
                                tempcol = selectdbrush;
                                e.Graphics.DrawString(menuname, drawFont, tempcol, padding + menulocationx, padding + y + menulocationy, drawFormat);
                            }
                            else
                            {
                                tempcol = normalcolor;
                                e.Graphics.DrawString(menuname, drawFont, tempcol, padding + menulocationx, padding + y + menulocationy, drawFormat);

                            }
                        }

                        //debug //dont select the first one of the 2
                        if (itemcount > 2 && searchfordebugitem >= 1)
                        {
                            if (itm.key == "debug")
                            {

                                selcted_item_index = itemcount;
                                selecteditemkey = "debug";
                                selecteditemdes = itm.discription;
                                selecteditm_add_index_index = itm.add_index_debug;
                                searchfordebugitem--;
                            }
                        } //debug


                        string menuvalue = "";
                        if (itm.key != "" && !itm.key.Contains("header_key_item"))
                        {
                            menuvalue = settings.getstring(itm.key) + (settings.get("debug", true) ? "" : "");
                        }

                        if (itm.type == typeof(int) && itm.key.ToLower().Contains("hot_key"))
                        {
                            // Keys key = (Keys)Enum.Parse(typeof(Keys), , true)
                            menuvalue = ((Keys)settings.get(itm.key, 0)).ToString();
                        }


                        drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                        e.Graphics.DrawString(menuvalue, drawFont, tempcol, (menuwidth - (padding)) + menulocationx, padding + y + menulocationy, drawFormat);
                        drawFormat = new StringFormat();


                        if (itemcount == selcted_item_index)
                        {
                            selecteditemkey = itm.key;
                            selecteditemdes = itm.discription;
                            selecteditm_add_index_index = itm.add_index_debug;
                            e.Graphics.FillRectangle(brushselected, menulocationx, menulocationy + y, padding + menuwidth - 1, 2);
                           e.Graphics.FillRectangle(brushselected, menulocationx, menulocationy + y + 2, 2, spacing - 2);
                            e.Graphics.FillRectangle(brushselected, menulocationx + menuwidth + 2, menulocationy + y + 2, 2, spacing - 2);

                        }
                        if (itemcount == 0)
                        {
                            //draw top
                           e.Graphics.FillRectangle(brushtitle, menulocationx, menulocationy + y, padding + menuwidth - 1, 2);
                            e.Graphics.FillRectangle(brushtitle, menulocationx, menulocationy + y + 2, 2, spacing - 2);
                            e.Graphics.FillRectangle(brushtitle, menulocationx + menuwidth + 2, menulocationy + y + 2, 2, spacing - 2);
                        }
                        if (itemcount == 1 && selcted_item_index != 1)
                        {
                            e.Graphics.FillRectangle(brushtitle, menulocationx, menulocationy + y, padding + menuwidth - 1, 2);

                        } else if (itemcount == selcted_item_index + 1)
                        {
                            e.Graphics.FillRectangle(brushselected, menulocationx, menulocationy + y, padding + menuwidth - 1, 2);

                        }

                        if (settings.get("debug_extra", true) && settings.get("debug", true))
                        {

                            if (extradebugcount2 < 30)  //debug
                            {
                                e.Graphics.DrawString("itm.key" + " " + itm.key + " " + settings.getstring(itm.key), drawFont, selectdbrush, deb2left, 50 + (extradebugcount2++ * 25), drawFormat);
                                e.Graphics.DrawString("itm.discription" + " " + itm.discription, drawFont, selectdbrush, deb2left, 50 + (extradebugcount2++ * 25), drawFormat);
                                e.Graphics.DrawString(" itm.add_index_debug" + " " + itm.add_index_debug, drawFont, selectdbrush, deb2left, 50 + (extradebugcount2++ * 25), drawFormat);
                                e.Graphics.DrawString("itm.show_index" + " " + itm.show_index, drawFont, selectdbrush, deb2left, 50 + (extradebugcount2++ * 25), drawFormat);
                                e.Graphics.DrawString(" itm.folded" + " " + itm.folded, drawFont, selectdbrush, deb2left, 50 + (extradebugcount2++ * 25), drawFormat);
                                e.Graphics.DrawString("itm.type" + " " + itm.type, drawFont, selectdbrush, deb2left, 50 + (extradebugcount2++ * 25), drawFormat);
                            }
                            else
                            {
                                e.Graphics.DrawString("itm.key" + " " + itm.key + " " + settings.getstring(itm.key), drawFont, selectdbrush, deb2left + 300, 50 + (extradebugcount3++ * 25), drawFormat);
                                e.Graphics.DrawString("itm.discription" + " " + itm.discription, drawFont, selectdbrush, deb2left + 300, 50 + (extradebugcount3++ * 25), drawFormat);
                                e.Graphics.DrawString(" itm.add_index_debug" + " " + itm.add_index_debug, drawFont, selectdbrush, deb2left + 300, 50 + (extradebugcount3++ * 25), drawFormat);
                                e.Graphics.DrawString("itm.show_index" + " " + itm.show_index, drawFont, selectdbrush, deb2left + 300, 50 + (extradebugcount3++ * 25), drawFormat);
                                e.Graphics.DrawString(" itm.folded" + " " + itm.folded, drawFont, selectdbrush, deb2left + 300, 50 + (extradebugcount3++ * 25), drawFormat);
                                e.Graphics.DrawString("itm.type" + " " + itm.type, drawFont, selectdbrush, deb2left + 300, 50 + (extradebugcount3++ * 25), drawFormat);
                            } //debug
                        }

                        maxitems_temp++;
                        itemcount++;

                        //debug
                        menu_height_counter += spacing;
                    }
                    if (itm.key == "header_key_item")
                    {
                        shownextitem = itm.folded ? 0 : 1;
                    }
                }

            }
            float yz = 5.0F + (spacing * itemcount);
            itemcount++;


            maxitems = maxitems_temp;


            e.Graphics.FillRectangle(brushbbg, menulocationx, menulocationy + yz, padding + menuwidth, padding - 2);
            e.Graphics.FillRectangle(brushwhite, menulocationx, menulocationy + yz, 2, padding - 2);

            e.Graphics.FillRectangle(brushwhite, menulocationx + menuwidth + 2, menulocationy + yz, 2, padding - 3);

           e.Graphics.FillRectangle(brushwhite, menulocationx, menulocationy + yz+1, padding + menuwidth - 1, 2);
            
            if (maxitems - 1 == selcted_item_index)
            {
                e.Graphics.FillRectangle(brushselected, menulocationx, menulocationy + yz, padding + menuwidth - 1, 2);
            }


            if (settings.get("debug_extra", true)&& settings.get("debug", true))
            {
                //debug
                e.Graphics.DrawString("selecteditemkey" + " " + selecteditemkey, drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                e.Graphics.DrawString("selecteditemkey string" + " " + settings.getstring(selecteditemkey), drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                e.Graphics.DrawString("selecteditemdes" + " " + selecteditemdes, drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                e.Graphics.DrawString("selecteditm_add_index_index" + " " + selecteditm_add_index_index, drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                e.Graphics.DrawString("selcted_item_index" + " " + selcted_item_index, drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                e.Graphics.DrawString("itemcount" + " " + itemcount, drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                e.Graphics.DrawString("searchfordebugitem" + " " + searchfordebugitem, drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                menu_height_counter += menulocationy + 7;
                e.Graphics.DrawString("maxitems" + " " + maxitems, drawFont, selectdbrush, 20, 50 + (extradebugcount++ * 25), drawFormat);
                e.Graphics.FillRectangle(brushtitle, menulocationx, menu_height_counter, menuwidth + 4, 1);
                //<debug
            }

        }

        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
       public static extern UInt32 GetWindowLong(IntPtr hWnd, int nIndex);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SetWindowLong(IntPtr hWnd, int nIndex, UInt32 dwNewLong);

        private Thread th;
        [DllImport("user32.dll")] private static extern int GetAsyncKeyState(Int32 i);

        public void add_hotkeys(Form _this)
        {
           
            th = new Thread(() =>
            {
                while (running)
                {
                    for (int i = 0; i < 255; i++)
                    {
                        int keyState = GetAsyncKeyState(i);
                        //  32769 for windows 10. -32767 for windows 7.
                        if (keyState == 1 || keyState == 32769 || keyState == -32767)
                        {
                            if (i == 1 || i == 2) { }
                            else
                            {
                                if (i == (int)Keys.F7)
                                {
                                    menu_active = !menu_active;
                                    _this.Invalidate();
                                }
                                if (menu_active)
                                {
                                    if (i == (int)Keys.Up)
                                    {
                                        if (selcted_item_index > 1)
                                            selcted_item_index--;
                                        _this.Invalidate();
                                    }
                                    if (i == (int)Keys.Down)
                                    {

                                        if (selcted_item_index < maxitems - 1)
                                            selcted_item_index++;
                                        _this.Invalidate();
                                    }


                                    if (i == (int)Keys.Right)
                                    {
                                      //  try
                                      //  {
                                            if (searchfordebugitem <1)
                                            {
                                                if (selecteditemkey == "header_key_item")
                                                {
                                                    if (settings.setting_items_list[selecteditm_add_index_index].discription.ToLower().Contains("exit"))
                                                    {
                                                        Application.Exit();
                                                        running = false;
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].discription.ToLower().Contains("close menu"))
                                                    {
                                                        menu_active = !menu_active;
                                                    }
                                                    else
                                                    {
                                                        settings.setting_items_list[selecteditm_add_index_index].folded = !settings.setting_items_list[selecteditm_add_index_index].folded;
                                                    }
                                                }
                                                else
                                                {
                                                    if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(bool))
                                                    {
                                                        if (selecteditm_add_index_index != 0)
                                                        {
                                                            if (settings.setting_items_list[selecteditm_add_index_index].key == "debug")
                                                            {
                                                                selcted_item_index = -1;
                                                                searchfordebugitem = 5;
                                                                selecteditemkey = "debug";
                                                                selecteditemdes = "";
                                                                selecteditm_add_index_index = -1;
                                                            }
                                                           
                                                            settings.set(selecteditemkey, !settings.get(selecteditemkey, false));
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show(selcted_item_index + " " + searchfordebugitem + " " + selecteditemkey + " " + selecteditemdes + " " + selecteditm_add_index_index + " ");

                                                        }
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(int))
                                                    {
                                                        if (System.Windows.Forms.Control.ModifierKeys.HasFlag(Keys.Control))
                                                            settings.set(selecteditemkey, settings.get(selecteditemkey, 0) + 10);
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, 0) + 1);

                                                    ///"menu_display_on_monitor"
                                                }
                                                else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(float))
                                                    {
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, (float)0.1F) + (float)0.1F); ;
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(double))
                                                    {
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, (double)0.0) + (double)0.01);
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(long))
                                                    {
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, (long)0) + 1);
                                                    }
                                                    else
                                                    {
                                                        // MessageBox.Show(selecteditm_add_index_index + " " + settings.setting_items_list[selecteditm_add_index_index].folded + " " + selecteditemkey + " val: " + settings.get(selecteditemkey, ""), selecteditemdes);
                                                    }

                                                }
                                            }
                                       // }
                                       // catch { }
                                        _this.Invalidate();
                                    }


                                    if (i == (int)Keys.Left)
                                    {
                                        try
                                        {
                                            if (searchfordebugitem <1)
                                            {
                                                if (selecteditemkey == "header_key_item")
                                                {
                                                    if (settings.setting_items_list[selecteditm_add_index_index].discription.ToLower().Contains("exit"))
                                                    {
                                                        Application.Exit();
                                                        running = false;
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].discription.ToLower().Contains("close menu"))
                                                    {
                                                        menu_active = !menu_active;
                                                    }
                                                    else
                                                    {
                                                        settings.setting_items_list[selecteditm_add_index_index].folded = !settings.setting_items_list[selecteditm_add_index_index].folded;

                                                    }
                                                }
                                                else
                                                {
                                                    if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(bool))
                                                    {
                                                        if (settings.setting_items_list[selecteditm_add_index_index].key == "debug")
                                                        {
                                                            selcted_item_index = -1;
                                                            searchfordebugitem = 5;
                                                            selecteditemkey = "debug";
                                                            selecteditemdes = "";
                                                            selecteditm_add_index_index = -1;
                                                        }

                                                        if (selecteditm_add_index_index != 0)
                                                        {
                                                            settings.set(selecteditemkey, !settings.get(selecteditemkey, false));
                                                        }
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(int))
                                                    {
                                                        if (System.Windows.Forms.Control.ModifierKeys.HasFlag(Keys.Control))
                                                            settings.set(selecteditemkey, settings.get(selecteditemkey, 0) - 10);
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, 0) - 1);

                                                        ///"menu_display_on_monitor"

                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(float))
                                                    {
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, (float)0.0F) - (float)0.1F);
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(double))
                                                    {
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, (double)0.0) - (double)0.01);
                                                    }
                                                    else if (settings.setting_items_list[selecteditm_add_index_index].type == typeof(long))
                                                    {
                                                        settings.set(selecteditemkey, settings.get(selecteditemkey, (long)1) - (long)1);
                                                    }
                                                    else

                                                    {
                                                        // MessageBox.Show(selecteditm_add_index_index + " " + settings.setting_items_list[selecteditm_add_index_index].folded + " " + selecteditemkey + " val: " + settings.get(selecteditemkey, ""), selecteditemdes);
                                                    }
                                                }
                                            }
                                        }
                                        catch { }
                                        _this.Invalidate();
                                    }

                                }



                            }
                        }
                    }
                    Thread.Sleep(10);
                }
            });
            th.Start();
        }

    }

}
