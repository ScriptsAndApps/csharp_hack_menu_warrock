﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nwh
{
    public class Menu_Settings
    {
        public class menu_item
        {
            public string discription = "empty";
            public int add_index_debug = -1;
            public int show_index = -2;
            public string key = "header_key_item";
            public Type type = typeof(string);
            private bool is_floded = false;
            public bool folded
            {
                get { 
                    return is_floded; 
                }   
                set {
                    new Menu_Settings().set(discription.Replace(" ", "_") + "_foldable_"+ key, value);
                    is_floded = value; 
                }
            }
            public menu_item(string _description,string _key, int _index,int _show_index,bool _is_floded,Type _type)
            {
                discription = _description;
                key = _key;
                add_index_debug = _index;
                show_index = _show_index;
                is_floded = _is_floded;
                type = _type;   
            }
        }

        public Menu_Settings()
        {  
            Initialize("settings.ini");
          
        }
        public void Initialize(string IniPath = null)
        {
            Path = new System.IO.FileInfo(IniPath ?? EXE + ".ini").FullName;
        }

        public List<menu_item> setting_items_list = new List<menu_item>();
        int item_add_index = 0;
        int padding_index_set_by_new_parent = -2;
        public void add_foldable_menu(string _name)
        {
            padding_index_set_by_new_parent = 0;
            setting_items_list.Add(new menu_item(_name, "header_key_item", item_add_index++, padding_index_set_by_new_parent, get(_name.Replace(" ", "_") + "_foldable_header_key_item", false), typeof(string)));
            padding_index_set_by_new_parent = 1;
        }
        public void add_title(string _name)
        {
            padding_index_set_by_new_parent = 0;
            setting_items_list.Add(new menu_item(_name, "header_key_item_title", item_add_index++, -1, false, typeof(string)));
            padding_index_set_by_new_parent = 1;
        }


 

        public void add_footer()
        {            //create menu folder
            add_foldable_menu("Other settings");

            int monitorselected = get("menu_display_on_monitor", 0);
            int screenwidth = Screen.AllScreens[0].Bounds.Width;
            if (monitorselected >=0 && monitorselected < Screen.AllScreens.Count())
            {
                screenwidth = Screen.AllScreens[monitorselected].Bounds.Width;
            }
            

            initialize_new_setting("Menu Location X", "menulocationx", (screenwidth - (get("debug", true) ? 20 : 20)) - get("width", 300));
            initialize_new_setting("Menu Location Y", "menulocationy", 10);
            initialize_new_setting("Opacity", "opacity", 0.70);
            initialize_new_setting("Background Aplha", "background_alpha", 255);
            initialize_new_setting("Select game monitor/display", "menu_display_on_monitor", 0);
            initialize_new_setting("Debug options", "debug",get("debug", true)); 
            initialize_new_setting("Extra debug options", "debug_extra", get("debug_extra", false), true);
            initialize_new_setting("Set menu Clickable", "clickable", get("clickable", false), true);

            initialize_new_setting("menu_open_hot_key", "menu_open_hot_key", (int)Keys.F7,true);
           add_foldable_menu("Close menu {Open-Close-Key}");
           add_foldable_menu("--- Exit ---");
        }
        public void initialize_new_setting(string description, string key, string value)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
           
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, padding_index_set_by_new_parent, false, value.GetType()));;
        }
        public void initialize_new_setting(string description, string key, string value, bool debug_only)
        {
            try
            {
                string temp = get(key, value);
                if (temp != "")
                    value = temp;
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, debug_only ? -2 : padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, bool value)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, padding_index_set_by_new_parent,false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, bool value, bool debug_only)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, debug_only ? -2 : padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, int value)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, int value, bool debug_only)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, debug_only ? -2 : padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, long value)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, long value, bool debug_only)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, debug_only ? -2 : padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, double value)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, double value, bool debug_only)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, debug_only ? -2 : padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, float value)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, padding_index_set_by_new_parent, false, value.GetType()));
        }
        public void initialize_new_setting(string description, string key, float value, bool debug_only)
        {
            try
            {
                value = get(key, value);
            }
            catch { }
            if (key == "") key = "key";
            if (description == "") description = key;
            setting_items_list.Add(new menu_item(description, key, item_add_index++, debug_only ? -2 : padding_index_set_by_new_parent, false, value.GetType()));
        }

        public void set(string key, string value)
        {
            try { Write(key, value.ToString()); } catch { }
            _string[key] = value;
        }
        public void set(string key, bool value)
        {
            try { Write(key, value.ToString()); } catch { }
            _bool[key] = value;
        }
        public void set(string key, float value)
        {
            try { Write(key, value.ToString("0.00")); } catch { }
            _float[key] = float.Parse(value.ToString("0.00"));
        }
        public void set(string key, int value)
        {
            try {
                if (key.ToLower().Contains("hot_key"))
                {
                    Write(key, ((Keys)value).ToString());
                }
                else { 
                    Write(key, value.ToString());
                }
            
            } catch { }
            _int[key] = value;
        }
        public void set(string key, long value)
        {
            try { Write(key, value.ToString()); } catch { }
            _long[key] = value;
        }
        public void set(string key, double value)
        {
            try { Write(key, string.Format("{0:N2}", value)); } catch { }
            _double[key] = double.Parse(string.Format("{0:N2}", value));
        }


        public string get(string key, string s)
        {
            if (_string.ContainsKey(key))
                    return _string[key];
            else
            {
                try {
                    if (KeyExists(key))
                    {
                        string t = Read(key);
                        if (t != "")
                            s = t;
                    }
                } catch { }
              
                set(key, s);
            }
            return s;
        }
        public bool get(string key, bool b)
        {
            if (_bool.ContainsKey(key))
                  return _bool[key];
            else
            {
                if (KeyExists(key))
                {
                    try { b = bool.Parse(Read(key)); } catch { }
                }
                set(key,b);
            }
            return b;
        }
        public float get(string key, float f)
        {
            if (_float.ContainsKey(key))
                return _float[key];
              else
            {
                if (KeyExists(key))
                {
                    try { f = float.Parse(Read(key)); } catch { }
                }
                set(key, f);
            }
            return f;
        }
        public int get(string key, int i)
        {
            if (_int.ContainsKey(key))
                return _int[key];
              else
            {
                if (KeyExists(key))
                {
                    string valk = Read(key);
                    try {
                        i = int.Parse(valk);
                    }
                    catch { }
                    try
                    {
                        if (key.ToLower().Contains("hot_key")&&!int.TryParse(valk, out _))
                        {
                            i = (int)(Keys)Enum.Parse(typeof(Keys), valk);
                        }
                    }
                    catch { }
                    
                 
                }
                set(key, i);
            }
            return i;
        }
        public long get(string key, long l)
        {
            if (_long.ContainsKey(key))
                return _long[key];
              else
            {
                if (KeyExists(key))
                {
                    try { l = long.Parse(Read(key)); } catch { }
                }
                set(key, l);
            }
            return l;
        }
        public double get(string key, double d)
        {
            if (_double.ContainsKey(key))
                return _double[key];
              else
            {
                if (KeyExists(key))
                {
                    try { d = double.Parse(Read(key)); } catch { }
                }
                set(key, d);
            }
            return d;
        }

        public Dictionary<string, string> _string = new Dictionary<string, string>();
        public Dictionary<string, bool> _bool = new Dictionary<string, bool>();
        public Dictionary<string, int> _int = new Dictionary<string, int>();
        public Dictionary<string, long> _long = new Dictionary<string, long>();
        public Dictionary<string, double> _double = new Dictionary<string, double>();
        public Dictionary<string, float> _float = new Dictionary<string, float>();
        public string getstring(string key)
        {
            if (_string.ContainsKey(key))
                try
                {
                    return _string[key].ToString();
                }
                catch { }
            if (_bool.ContainsKey(key))
                try
                {
                    return _bool[key].ToString();
                }
                catch { }
            if (_int.ContainsKey(key))
                try
                {
                    return _int[key].ToString();
                }
                catch { }

            if (_long.ContainsKey(key))
                try
                {
                    return _long[key].ToString();
                }
                catch { }
            if (_double.ContainsKey(key))
                try
                {
                    return _double[key].ToString();
                }
                catch { }
            if (_float.ContainsKey(key))
                try
                {
                    return _float[key].ToString()+"F";
                }
                catch { }
            return "null";
        }

        string Path;
        string EXE = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;

        [System.Runtime.InteropServices.DllImport("kernel32", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern long WritePrivateProfileString(string Section, string Key, string Value, string FilePath);

        [System.Runtime.InteropServices.DllImport("kernel32", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern int GetPrivateProfileString(string Section, string Key, string Default, StringBuilder RetVal, int Size, string FilePath);

        public string Read(string Key, string Section = null)
        {
            var RetVal = new StringBuilder(255);
            GetPrivateProfileString(Section ?? EXE, Key, "", RetVal, 255, Path);
            return RetVal.ToString();
        }

        public void Write(string Key, string Value, string Section = null)
        {
            WritePrivateProfileString(Section ?? EXE, Key, Value, Path);
        }

        public void DeleteKey(string Key, string Section = null)
        {
            Write(Key, null, Section ?? EXE);
        }

        public void DeleteSection(string Section = null)
        {
            Write(null, null, Section ?? EXE);
        }

        public bool KeyExists(string Key, string Section = null)
        {
            return Read(Key, Section).Length > 0;
        }

    }
}
